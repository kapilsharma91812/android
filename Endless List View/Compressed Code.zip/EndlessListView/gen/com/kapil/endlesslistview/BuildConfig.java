/** Automatically generated file. DO NOT MODIFY */
package com.kapil.endlesslistview;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}